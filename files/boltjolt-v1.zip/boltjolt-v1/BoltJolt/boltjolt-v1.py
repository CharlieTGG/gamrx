import time
import re
import os
import subprocess
import sys
import math
from googletrans import Translator
import random

print("Hello, I am BoltJolt!")
print("For a list of possible commands, please run the command: boltjolt.getsyntax")

LANGUAGE_MAP = {
    "english": "en",
    "spanish": "es",
    "french": "fr",
    "german": "de",
    "italian": "it",
    "portuguese": "pt",
    "chinese": "zh-cn",
    "japanese": "ja",
    "korean": "ko",
    "russian": "ru",
    "arabic": "ar",
    "hindi": "hi",
}

CURRENCY_RATES = {
    ("usd", "eur"): 0.85,
    ("usd", "gbp"): 0.75,
    ("eur", "usd"): 1.18,
    ("gbp", "usd"): 1.33,
}

GENZ_WORD_DICTIONARY = {
    "mew": "To do mewing.",
    "mewing": "When you stick your tongue to the top of your mouth and suck your cheeks in in the act of trying to fix your jawline.",
    "rizz": "Another word for flirting.",
    "rizzler": "Someone who has a lot of rizz.",
    "gyat": "A large booty.",
    "sigma": "Someone who is very cool and/or masculine.",
    "gigachad": "A buff meme man referred to as the 'ultimate sigma' and 'the rizzler' whose real name is Ernest Khalimov.",
}

def main():
    
    while True:
        command = input("BoltJolt> ")
        
        if command.startswith("boltjolt.shutdown"):
            print("Goodbye for now! ~ BoltJolt")
            time.sleep(2)
            print("Shutting down...")
            sys.exit()
        
        execute_command(command)
        
def execute_command(command):
    
    if command.startswith("boltjolt"):
        
            if command.startswith("boltjolt.getsyntax"): # 5 spaces per column
                print("BoltJolt Syntax:")
                print("")
                print("     boltjolt")
                print("     Commands that control or tell us information about BoltJolt.")
                print("")
                print("          boltjolt.getsyntax")
                print("          Shows us all of the commands we can run in BoltJolt, what they do and how to use them correctly.")
                print("")
                print("          boltjolt.shutdown")
                print("          Closes BoltJolt.")
                print("")
                print("          boltjolt.clear")
                print("          Clears the Terminal.")
                print("")
                print("     simonsays")
                print("     Repeats the content between [ and ].")
                print("")
                print("     ls")
                print("     Lists the contents of a folder based upon directory input.")
                print("")
                print("     pwd")
                print("     Displays the path of the folder you put BoltJolt in.")
                print("")
                print("     run")
                print("     Runs an application based upon directory input.")
                print("")
                print("     banner")
                print("     Displays the welcome message.")
                print("")
                print("     google")
                print("     Commands that use Google.")
                print("")
                print("          google.translate")
                print("          Translates from one language to another: google.translate from(original language) to(new language) [text].")
                print("")
                print("     math")
                print("     Mathematic commands.")
                print("")
                print("          math.addition")
                print("          Adds numbers together: math.addition [num1] [num2] [num3] etc...")
                print("")
                print("          math.subtraction")
                print("          Takes numbers away from each other: math.subtraction [num1] [num2] [num3] etc...")
                print("")
                print("          math.multiplication")
                print("          Multiplies numbers: math.multiplication [num1] [num2] [num3] etc...")
                print("")
                print("          math.division")
                print("          Divides numbers: math.division [num1] [num2] [num3] etc...")
                print("")
                print("          math.getsquareroot")
                print("          Finds the square root of a number: math.getsquareroot [num]")
                print("")
                print("          math.converttodecimal")
                print("          Converts numbers to a decimal: math.converttodecimal [num]")
                print("")
                print("          math.converttopercentage")
                print("          Converts numbers to a percentage: math.converttopercentage [num]")
                print("")
                print("          math.currency")
                print("          Converts one currency to another currency (may be outdated): math.currency [currency1] [num1] [currency2] [num2] WARNING: BROKEN!")
                print("")
                print("     random")
                print("     Randomised content.")
                print("")
                print("          random.joke")
                print("          Randomly generates jokes.")
                print("")
                print("     define")
                print("     Find the definition of cirtern words.")
                print("")
                print("          define.genz")
                print("          Find the definition of popular words among Gen Zs: define.genz [word]")
                print("")
                
            elif command.startswith("boltjolt.clear"):
                os.system("cls" if os.name == "nt" else "clear")
                
            else:
                print("Hi there, what would you like me to do today?")
                
    if command.startswith("simonsays"):
        match = re.search(r"\[(.*?)\]", command)
        if match:
            content = match.group(1)
            print(content)
        else:
            print("Incorrect syntax: Make sure the content you want repeating is between [ and ].")
            
    elif command.startswith("ls"):
     for file in os.listdir():
        print(file)
        
    elif command.startswith("pwd"):
        print(os.getcwd())
        
    elif command.startswith("run"):
        _, *args = command.split()
        try:
            subprocess.run(args)
        except Exception as e:
         print(f"Error: {e}")
         
    elif command.startswith("banner"):
        print("Hello, I am BoltJolt!")
        print("For a list of possible commands, please run the command: boltjolt.getsyntax")
        
    elif command.startswith("google"):
        
        if command.startswith("google.translate"):
         match = re.search(r"from\((.*?)\) to\((.*?)\) \[(.*?)\]", command)
         if match:
            from_lang = match.group(1).strip().lower()
            to_lang = match.group(2).strip().lower()
            text = match.group(3).strip()

            if from_lang in LANGUAGE_MAP and to_lang in LANGUAGE_MAP:
                google_translate(text, from_lang, to_lang)
            else:
                print("Invalid languages. Supported languages are: " + ", ".join(LANGUAGE_MAP.keys()))
         else:
             print("Incorrect syntax. Use: google.translate from(language) to(language) [text]")
        else:
            print("What do you want to use Google for?")
            
    elif command.startswith("math"):
        
     if command.startswith("math.addition"):
         match = re.findall(r"[-+]?\d*\.\d+|\d+", command)
         numbers = [float(num) for num in match]
         result = sum(numbers)
         print(f"Result of addition: {result}")

     elif command.startswith("math.subtraction"):
        match = re.findall(r"[-+]?\d*\.\d+|\d+", command)
        numbers = [float(num) for num in match]
        result = numbers[0] - sum(numbers[1:])
        print(f"Result of subtraction: {result}")
    
     elif command.startswith("math.multiplication"):
        match = re.findall(r"[-+]?\d*\.\d+|\d+", command)
        numbers = [float(num) for num in match]
        result = 1
        for num in numbers:
            result *= num
        print(f"Result of multiplication: {result}")
    
     elif command.startswith("math.division"):
        match = re.findall(r"[-+]?\d*\.\d+|\d+", command)
        numbers = [float(num) for num in match]
        result = numbers[0]
        for num in numbers[1:]:
            if num == 0:
                print("Error: Division by zero is not allowed.")
                return
            result /= num
        print(f"Result of division: {result}")

     elif command.startswith("math.getsquareroot"):
        match = re.findall(r"[-+]?\d*\.\d+|\d+", command)
        if match:
            number = float(match[0])
            if number < 0:
                print("Error: Cannot get the square root of a negative number.")
            else:
                result = math.sqrt(number)
                print(f"Square root: {result}")
        else:
            print("Please provide a valid number.")

     elif command.startswith("math.converttodecimal"):
        match = re.findall(r"[-+]?\d*\.\d+|\d+", command)
        if match:
            number = float(match[0])
            print(f"Decimal form: {number}")
        else:
            print("Please provide a valid number.")

     elif command.startswith("math.converttopercentage"):
        match = re.findall(r"[-+]?\d*\.\d+|\d+", command)
        if match:
            number = float(match[0])
            result = number * 100
            print(f"Percentage: {result}%")
        else:
            print("Please provide a valid number.")

     elif command.startswith("math.currency"):
        match = re.findall(r"\[([a-zA-Z]+)\] (\d+) \[([a-zA-Z]+)\]", command)
        if match:
            currency1, num1, currency2 = match[0]
            num1 = float(num1)

            key = (currency1.lower(), currency2.lower())
            if key in CURRENCY_RATES:
                rate = CURRENCY_RATES[key]
                result = num1 * rate
                print(f"Converted {currency1} to {currency2}: {result}")
            else:
                print("Currency conversion rate not available.")
        else:
            print("Incorrect syntax. Usage: math.currency [currency1] [num1] [currency2]")
            
     else:
         print("What do you want to solve in math?")
         
    elif command.startswith("random"):
        
        if command.startswith("random.joke"):
            jokes = ["Why did the JavaScript developer wear glasses? Because he couldn't see sharp!"]
            print(random.choice(jokes))
            
        else:
            print("What do you want to be randomly generated?")
            
    elif command.startswith("define"):
        
        if command.startswith("define.genz"):
            match = re.search(r"\[([a-zA-Z]+)\]", command)
            if match:
                word = match.group(1)
                
                word = word.lower()
                definition = GENZ_WORD_DICTIONARY.get(word)
                if definition:
                    print(f"Definition of {word} according to Gen Zs: {definition}")
                else:
                    print(f"Im not sure what {word} means.")
                    
            else:
                print("Syntax Error: Make sure to put the word between [ and ].")
            
    else:
      print(f"Unknown command: {command}")
        
def google_translate(text, src_lang, dest_lang):
    """Translates the input text from the source language to the destination language."""
    translator = Translator()
    try:
        translation = translator.translate(text, src=LANGUAGE_MAP[src_lang], dest=LANGUAGE_MAP[dest_lang])
        print(f"Translated text: {translation.text}")
    except Exception as e:
        print(f"Error translating text: {e}")
        
if __name__ == "__main__":
    main()