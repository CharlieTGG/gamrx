READ ME BEFORE YOU START ANYTHING!
Note: BoltJolt was made for Windows so if your not using Windows you may struggle to use it.
Here is a step by step tutorial on how to set up BoltJolt Version 1:
1) Extract the .zip file somewhere on your PC.
2) Delete the .zip file.
3) Drag the 'BoltJolt Version 1' file into your Desktop Folder and place it somewhere on your desktop.
4) Drag the BoltJolt folder into your Documents Folder.
5) Put this README.txt file somewhere or delete it, it's really up to you on this step.
6) Enjoy BoltJolt!

If you have any suggestions for the next version please email me at admin@gamrx.xyz.

If you can't open the 'BoltJolt Version 1' file create it yourself:
1) Go onto your Desktop.
2) Right-click somewhere and go to 'New' and then 'Shortcut'.
3) Click browse and find your 'BoltJolt' folder (if you followed the steps correctly it should be located in your Documents folder.)
4) Go into the 'BoltJolt' folder, then the 'dist' and then select the file named 'boltjolt-v1.exe'.
5) Click 'Next' and name the shortcut whatever you like, I just named it 'BoltJolt Version 1' for your convenience!